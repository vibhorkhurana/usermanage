const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const schema = new Schema({
    deviceId: { type: String, unique: true, required: true },
    deviceType: { type: String, required: true },
    userName: { type: String, required: true },
    createdDate: { type: Date, default: Date.now }
});

schema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('DeviceGraph', schema);