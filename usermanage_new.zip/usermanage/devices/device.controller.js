const express = require('express');
const router = express.Router();
const deviceService = require('./device.service');

//routes
router.post('/register', register);
router.get('/:id',getById);
router.get('/:user',getByUser);
router.get('/',getAll);
router.put('/:id',update);
router.delete('/:id',_delete);

module.exports=router;

function register(req,res,next){
    //TODO: Write the code to create

    // deviceService.create(req.body)
    // .then(() => res.json({}))
    // .catch(err => next(err))
    console.log(req.body);
}

function getAll(req,res,next){
    deviceService.getAll()
    .then(devices => console.log(devices))
    .catch(err => next(err))
}